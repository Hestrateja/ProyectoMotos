=== Model's Resource ===
Platform : Nintendo DS
Game     : Final Fantasy III
Model    : ENEMY/175-Gomory
========================

Contents:
- DAE COLLADA Model(s) (with animations)
- FBX Autodesk Model(s) (with animations)
- PNG Texture files (with alpha channels)

Ripped by Lexou Duck, using Apicula and Tinke
For more info on how to properly import these models into your 3D program, check out:
https://github.com/scurest/apicula/wiki

Tue, May 14, 2019  4:19:42 AM
